MAIN_MENU_CHOICES = [
    ("(1)", "Adjust Increment Level"),
    ("(2)", "Select Mixer")
]

MIXER_CHOICES = [
    ("Master", "Master"),
	("PCM", "PCM" ),
	("Line Out", "Line Out"),
	("Headphone", "Headphone")
]