import alsaaudio

def set_volume(mixer, increment, direction):
    m = alsaaudio.Mixer(mixer)

    if direction in ['up']:
        next_vol = m.getvolume()[0] + increment

        if next_vol > 100:
            next_vol = 100
        
        m.setvolume(next_vol)
    elif direction in ['down']:
        next_vol = m.getvolume()[0] - increment

        if next_vol < 0:
            next_vol = 0
        
        m.setvolume(next_vol)
    elif direction in ['mute']:
        curvol = m.getmute()[0]
        if curvol == 1:
            m.setmute(0)
        else:
            m.setmute(1)